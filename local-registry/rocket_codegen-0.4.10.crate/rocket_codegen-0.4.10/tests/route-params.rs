// #[post("/<_name>?<_query>", format = "application/json", data = "<user>", rank = 2)]
// fn get(
//     _name: &RawStr,
//     _query: User,
//     user: Form<User>,
//     _cookies: Cookies
// ) -> String {
//     format!("{}:{}", user.name, user.nickname)
// }

