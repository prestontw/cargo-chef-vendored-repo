use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct A {
    pub field: String,
}

fn main() {}
